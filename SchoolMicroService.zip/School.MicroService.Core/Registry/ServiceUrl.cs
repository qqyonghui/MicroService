﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School.MicroService.Core.Registry
{
    public class ServiceUrl
    {
        public string Url { get; set; }
    }
}
